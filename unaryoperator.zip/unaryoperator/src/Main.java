
public class Main {
    public static void main(String[] args) {
     //Unary Operator
        int x=5;
        int y= -x;
        int z=-y;
        System.out.println(x);
        System.out.println(y);
        System.out.println(z);
        //Pre increment
        int a=5;
        a=a+9;
        System.out.println(a);
        //pre decrement
        int b=10;
        b=b-3;
        System.out.println(b);
        b++;
        System.out.println(b);
        System.out.println(b++);
        System.out.println(b);
        System.out.println(++b);
        System.out.println(--b);
        System.out.println(b--);
        System.out.println(b);
        int q=10;
        System.out.println(--q);
        System.out.println(q);
        System.out.println(q--);
        System.out.println(q);
    }
}